package restaurant_class;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Over_walkin extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int flag;
	JFrame over;
	JButton sure,quit;
	JTextField tid;
	Box basebox,boxV1,boxV2;

	void over(){
		over=new JFrame("����");
		over.setLayout(new FlowLayout());
		boxV1=Box.createVerticalBox();
		boxV1.add(new JLabel("�������������ţ�"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV2=Box.createVerticalBox();
		tid=new JTextField(10);
		boxV2.add(tid);
		boxV2.add(Box.createVerticalStrut(8));
		basebox=Box.createHorizontalBox();
		basebox.add(boxV1);
		basebox.add(Box.createHorizontalStrut(16));
		basebox.add(boxV2);
		sure=new JButton("ȷ��");
		quit=new JButton("ȡ��");
		sure.addActionListener(this);
		quit.addActionListener(this);
		over.add(basebox);
		over.add(sure);
		over.add(quit);
		over.setBounds(300, 300, 300, 200);
		over.setVisible(true);
		over.validate();
		over.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		if(e.getSource()==sure){
			String b=null;
			Sql_delete sd=new Sql_delete();
			String tnumber=tid.getText();
			String sql="select time from walkin where (table_id='"+tnumber+"')";
			Sql_connect sConnect= new Sql_connect();
			try {
				b=sConnect.sqlconnect(sql, "time");
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
			if(b.equals("0")){
				JOptionPane.showMessageDialog(null,"�����������Ϣ��","��ʾ",JOptionPane.WARNING_MESSAGE);
				tid.setText("");
			}else {
				try {
					sd.sqldrop("delete from walkin where (table_id='"+tnumber+"')");
					JOptionPane.showMessageDialog(null,"���˳ɹ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
					flag=1;
					over.dispose();
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		}
		if(e.getSource()==quit){
			over.dispose();
		}
	}

}
