package restaurant_class;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Now_add extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JFrame add;
	String c,d,t,tableid,button;
	JTextField cover,date,times,tid;
	JButton sure,quit;
	Box basebox,boxV1,boxV2;
	void nowadd(String s){
		add = new JFrame(s);
		add.setLayout(new FlowLayout());
		boxV1=Box.createVerticalBox();
		boxV1.add(new JLabel("������������"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV1.add(new JLabel("���������ڣ�"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV1.add(new JLabel("������ʱ�䣺"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV1.add(new JLabel("��������Ҫ�Ͳ͵����ţ�"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV2=Box.createVerticalBox();
		cover=new JTextField(c);
		boxV2.add(cover);
		boxV2.add(Box.createVerticalStrut(8));
		date=new JTextField(d);
		boxV2.add(date);
		boxV2.add(Box.createVerticalStrut(8));
		times=new JTextField(t);
		boxV2.add(times);
		boxV2.add(Box.createVerticalStrut(8));
		tid=new JTextField(tableid);
		boxV2.add(tid);
		boxV2.add(Box.createVerticalStrut(8));
		basebox=Box.createHorizontalBox();
		basebox.add(boxV1);
		basebox.add(Box.createHorizontalStrut(16));
		basebox.add(boxV2);
		sure=new JButton("ȷ��");
		quit=new JButton("ȡ��");
		sure.addActionListener(this);
		quit.addActionListener(this);
		add.add(basebox);
		add.add(sure);
		add.add(quit);
		add.setBounds(400, 300, 300, 300);
		add.setVisible(true);
		add.validate();
		add.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		if(e.getSource()==sure){
			String b = null;
			Sql_nowinsert sn=new Sql_nowinsert();
			Sql_connect sc = new Sql_connect();
			String covers=cover.getText();
			String time=times.getText();
			String da=date.getText();
			String tnumber=tid.getText();
			String sql2 = "select time from walkin where (date = '"+da+"' and table_id = '"+tnumber+"')";
			try {
				b=sc.sqlconnect(sql2, "time");
			} catch (Exception e2) {
				// TODO �Զ����ɵ� catch ��
				e2.printStackTrace();
			}
			if(b.equals("0")){
				try {
					sn.sqlinsert(Integer.parseInt(covers),da, time, Integer.parseInt(tnumber));
					add.dispose();
					JOptionPane.showMessageDialog(null,"�ɹ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}else {
				JOptionPane.showMessageDialog(null,"���������ڳԣ�������ѡ��","��ʾ",JOptionPane.INFORMATION_MESSAGE);
				cover.setText("");
				times.setText("");
				date.setText("");
				tid.setText("");
			}
		}
		if(e.getSource()==quit){
			add.dispose();
		}
	}

}
