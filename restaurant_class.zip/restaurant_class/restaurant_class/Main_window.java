package restaurant_class;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import restaurant_class.CalendarFrame;

public class Main_window {
	public static void main(String args[]) throws Exception{
		
		welcome w=new welcome();
		w.wel();
		new Thread(w).start();
	}

}

class welcome extends JFrame implements ActionListener,Runnable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JFrame welc;
	JPanel panel;
	JScrollPane jsPane;
	JLabel j=new JLabel();
	SimpleDateFormat sd=new SimpleDateFormat("yyyy��MM��dd��       EEE     HH:mm:ss");
	JTable table;
	JButton check;
	JButton add,delete,walkin,leave;
	String a[][] = new String[7][4];
	Object location[]={"","1","2","3"};
	String dates,times;
	Calendar n = Calendar.getInstance();
	int hour=0,minute=0,second=0,m;
	void wel(){
		String b=null;
		String b1 = null,b2 = null;
		String flag[] = new String [21];
		int d[]=new int[4];
		welc=new JFrame("����ԤԼϵͳ");
		j.setText("                                          ��ǰʱ�䣺       "+sd.format(new Date()));
		dates=String.valueOf(n.get(Calendar.YEAR))+"-"+String.valueOf(n.get(Calendar.MONTH)+1)+"-"+
		      String.valueOf(n.get(Calendar.DAY_OF_MONTH));
		m=n.get(Calendar.HOUR_OF_DAY);
		if(m>=8&&m<10){
			times="8:00-10:00";
		}else if(m>=10&&m<12){
			times="10:00-12:00";
		}else if(m>=12&&m<14){
			times="12:00-14:00";
		}else if(m>=14&&m<16){
			times="14:00-16:00";
		}else if(m>=16&&m<18){
			times="16:00-18:00";
		}else{
			times="18:00-20:00";
		}
		Sql_connect sc = new Sql_connect();
		for(int i=0;i<21;i++){
			String sql = "select custom_id from reservation where (date = '"+dates+"' and time = '"+times+"' and table_id = "+(i+1)+")";
			String sql1 = "select number_T from table_r where(table_id = '"+(i+1)+"')";
			String sql2 = "select time from walkin where (date = '"+dates+"' and table_id = '"+(i+1)+"')";
			try {
				b=sc.sqlconnect(sql,"custom_id");
				b1 = sc.sqlconnect(sql1,"number_T");
				b2 = sc.sqlconnect(sql2, "time");
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
			Pattern pattern = Pattern.compile("\\d+");
			Matcher matcher = pattern.matcher(b2);
			int q = 0;
			while (matcher.find()) {
				d[q]=Integer.parseInt((matcher.group(0)));
				q++;
			}
			System.out.println(b2);
			if(b.equals("0")&&b2.equals("0")){
				flag[i]="��"+(i+1)+"��("+b1+"����)û�б�ʹ����ûԤԼ";
			}else if(!b.equals("0")) {
				flag[i]="��"+(i+1)+"��("+b1+"����)��ԤԼ";
			}else if (!b2.equals("0")) {
				flag[i]="��"+(i+1)+"��("+b1+"����)���ڱ�ʹ��";
			}
		}
		for(int i=0;i<3;i++){
			a[0][i+1]=flag[i];
			a[1][i+1]=flag[i+3];
			a[2][i+1]=flag[i+6];
			a[3][i+1]=flag[i+9];
			a[4][i+1]=flag[i+12];
			a[5][i+1]=flag[i+15];
			a[6][i+1]=flag[i+18];
		}
		for(int j=0;j<7;j++){
			a[j][0] = "               "+String.valueOf(j+1);
		}
		table=new JTable(a,location);
		table.getColumnModel().getColumn(1).setCellEditor(new Nowbutton());
		table.getColumnModel().getColumn(2).setCellEditor(new Nowbutton());
		table.getColumnModel().getColumn(3).setCellEditor(new Nowbutton());
		Nowbutton.date=dates;
		Nowbutton.times=times;
		Nowbutton.t=String.valueOf(m)+":"+String.valueOf(n.get(Calendar.MINUTE));
		walkin=new JButton("���˽�����������뿪");
		leave=new JButton("����");
		check=new JButton("��ѯ");
		add=new JButton("����ԤԼ");
		delete=new JButton("ȡ��ԤԼ");
		walkin.addActionListener(this);
		leave.addActionListener(this);
		check.addActionListener(this);
		add.addActionListener(this);
		delete.addActionListener(this);
		panel=new JPanel();
		panel.add(walkin);
		panel.add(leave);
		panel.add(check);
		panel.add(add);
		panel.add(delete);
		jsPane=new JScrollPane(table);
		welc.setLayout(new BorderLayout());
		welc.add(j, BorderLayout.NORTH);
		welc.add(jsPane, BorderLayout.CENTER);
		welc.add(panel, BorderLayout.SOUTH);
		welc.setBounds(360, 200, 900,240);
		welc.setVisible(true);
		welc.validate();
		welc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		if(e.getSource()==walkin){
			welcome we=new welcome();
			we.wel();
			new Thread(we).start();
			welc.dispose();
			
		}
		if(e.getSource()==leave){
			Over_walkin ow=new Over_walkin();
			ow.over();
		}
		if(e.getSource()==check){
			CalendarFrame cf=new CalendarFrame();
			cf.calwindow();
		}
		if(e.getSource()==add){
			Add_record ar=new Add_record();
			ar.add("ԤԼ");
			ar.d="";
			ar.t="";
			ar.tableid="";
		}
		if(e.getSource()==delete){
			Delete_record dr=new Delete_record();
			dr.delete();
			dr.d="";
			dr.t="";
			dr.tableid="";
		}
		
	}
	@Override
	public void run() {
		// TODO �Զ����ɵķ������
		while(true){
			try{
			Thread.sleep(1000);
			}
			catch(InterruptedException e){
				
			}
			j.setText("                                          ��ǰʱ�䣺       "+sd.format(new Date()));
			hour = n.get(Calendar.HOUR_OF_DAY);
			minute = n.get(Calendar.MINUTE);
			second = n.get(Calendar.SECOND);
			if(hour%2==0&&minute==0&&second==0){
				String b=null,b1=null,b2=null;
				int d[]=new int[4];
				String flag[] = new String [21];
				Sql_connect sc = new Sql_connect();
				times=String.valueOf(hour)+":00-"+String.valueOf(hour+2)+":00";
				for(int i=0;i<21;i++){
					String sql = "select custom_id from reservation where (date = '"+dates+"' and "
							+ "time = '"+times+"' and table_id = "+(i+1)+")";
					String sql1 = "select number_T from table_r where(table_id = '"+(i+1)+"')";
					String sql2 = "select time from walkin where (date = '"+dates+"' and table_id = '"+(i+1)+"')";
					try {
						b=sc.sqlconnect(sql,"custom_id");
						b1 = sc.sqlconnect(sql1,"number_T");
						b2 = sc.sqlconnect(sql2, "time");
					} catch (Exception e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
					Pattern pattern = Pattern.compile("\\d+");
					Matcher matcher = pattern.matcher(b2);
					int q = 0;
					while (matcher.find()) {
						d[q]=Integer.parseInt((matcher.group(0)));
						q++;
					}
					if(b.equals("0")&&b2.equals("0")){
						flag[i]="��"+(i+1)+"��("+b1+"����)û�б�ʹ����ûԤԼ";
					}else if(!b.equals("0")) {
						flag[i]="��"+(i+1)+"��("+b1+"����)��ԤԼ";
					}else if (d[0]<n.get(Calendar.HOUR_OF_DAY)||
							(d[0]==n.get(Calendar.HOUR_OF_DAY)&&d[1]<n.get(Calendar.MINUTE))) {
						flag[i]="��"+(i+1)+"��("+b1+"����)���ڱ�ʹ��";
					}
				}
				for(int i=0;i<3;i++){
					a[0][i+1]=flag[i];
					a[1][i+1]=flag[i+3];
					a[2][i+1]=flag[i+6];
					a[3][i+1]=flag[i+9];
					a[4][i+1]=flag[i+12];
					a[5][i+1]=flag[i+15];
					a[6][i+1]=flag[i+18];
				}
				for(int j=0;j<7;j++){
					a[j][0] = "               "+String.valueOf(j+1);
				}
				table.repaint();
				table.getColumnModel().getColumn(1).setCellEditor(new Nowbutton());
				table.getColumnModel().getColumn(2).setCellEditor(new Nowbutton());
				table.getColumnModel().getColumn(3).setCellEditor(new Nowbutton());
			}

			}
		
	}
}
