package restaurant_class;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

import restaurant_class.CalendarBean;

public class CalendarFrame extends JFrame implements ItemListener,TreeSelectionListener,ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JFrame calw;
	JTable table;
	JTree tree=null;
	JLabel tishi=new JLabel("������Ҫ��ѯ������:");
	JTextField date;
	Box boxv1,boxv2,basebox;
	JButton check;
	DefaultMutableTreeNode root;
	Object name[]={"������","����һ","���ڶ�","������","������","������","������"};
	JComboBox<String> yearList;
	int year,month;
	String yString;
	CalendarBean calendar;
	String cal[][];
	Calendar n = Calendar.getInstance();
	String first=String.valueOf(n.get(Calendar.YEAR));
	String second=String.valueOf(n.get(Calendar.YEAR)+1);
	String item[]={first,second};
	JScrollPane scrollTree,scrollTable;
	JSplitPane split;
	public void calwindow(){
		calw=new JFrame("����ԤԼ");
		calendar=new CalendarBean();
		yearList=new JComboBox<String>();   //����һ�������˵�
		for(int i=0;i<item.length;i++){
			yearList.addItem(item[i]);
		}
		yearList.addItemListener(this);
		root=new DefaultMutableTreeNode(item[0]);
		year=Integer.parseInt(item[0]);
		month=1;
		DefaultMutableTreeNode month1[]=new DefaultMutableTreeNode[13];
		for(int i=1;i<=12;i++){
			month1[i]=new DefaultMutableTreeNode(""+i);
			root.add(month1[i]);
		}
		tree=new JTree(root);
		add(new JScrollPane(tree),BorderLayout.WEST);
		tree.addTreeSelectionListener(this);
		calendar.setyear(year);
		calendar.setmonth(month);
		cal=calendar.getcalendar();
		table=new JTable(cal,name);
		table.getColumnModel().getColumn(0).setCellEditor(new Mybutton());
		table.getColumnModel().getColumn(1).setCellEditor(new Mybutton());
		table.getColumnModel().getColumn(2).setCellEditor(new Mybutton());
		table.getColumnModel().getColumn(3).setCellEditor(new Mybutton());
		table.getColumnModel().getColumn(4).setCellEditor(new Mybutton());
		table.getColumnModel().getColumn(5).setCellEditor(new Mybutton());
		table.getColumnModel().getColumn(6).setCellEditor(new Mybutton());
		scrollTable=new JScrollPane(table);
		scrollTree=new JScrollPane(tree);
		split=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,true,scrollTree,scrollTable);
		boxv1=Box.createVerticalBox();
		boxv1.add(tishi);
		boxv2=Box.createVerticalBox();
		date=new JTextField(2);
		boxv2.add(date);
		basebox=Box.createHorizontalBox();
		basebox.add(boxv1);
		basebox.add(Box.createHorizontalStrut(16));
		basebox.add(boxv2);
		basebox.add(Box.createHorizontalStrut(16));
		check=new JButton("��ѯ");
		check.addActionListener(this);
		basebox.add(check);
		calw.add(yearList,BorderLayout.NORTH);
		calw.add(split, BorderLayout.CENTER);
		calw.add(basebox, BorderLayout.SOUTH);
		calw.setBounds(300, 260, 600, 280);
		calw.setVisible(true);
		split.setDividerLocation(0.2);
		calw.validate();
		calw.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}
	@Override
	public void valueChanged(TreeSelectionEvent e) {
		// TODO �Զ����ɵķ������
		DefaultMutableTreeNode monthNode=(DefaultMutableTreeNode)tree.getLastSelectedPathComponent();
		if(monthNode.isLeaf()){
			month=Integer.parseInt(monthNode.toString().trim());
			calendar.setmonth(month);
			cal=calendar.getcalendar();
			split.remove(scrollTable);
			table=new JTable(cal,name);
			table.getColumnModel().getColumn(0).setCellEditor(new Mybutton());
			table.getColumnModel().getColumn(1).setCellEditor(new Mybutton());
			table.getColumnModel().getColumn(2).setCellEditor(new Mybutton());
			table.getColumnModel().getColumn(3).setCellEditor(new Mybutton());
			table.getColumnModel().getColumn(4).setCellEditor(new Mybutton());
			table.getColumnModel().getColumn(5).setCellEditor(new Mybutton());
			table.getColumnModel().getColumn(6).setCellEditor(new Mybutton());
			scrollTable=new JScrollPane(table);
			split.add(scrollTable,JSplitPane.RIGHT);
			calw.validate();
			split.setDividerLocation(0.2);
			Mybutton.bm=String.valueOf(month);
			if(yString==null){
				yString=first;
				Mybutton.by=yString;
			}else{
				Mybutton.by=yString;
			}
		}
		
	}
	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO �Զ����ɵķ������
		String year1=yearList.getSelectedItem().toString().trim();
		yString =year1;
		year=Integer.parseInt(year1);
		calendar.setyear(year);
		root=new DefaultMutableTreeNode(year1);
		DefaultMutableTreeNode month1[]=new DefaultMutableTreeNode[13];
		for(int i=1;i<=12;i++){
			month1[i]=new DefaultMutableTreeNode(""+i);
			root.add(month1[i]);
		}
		split.remove(scrollTree);
		tree=new JTree(root);
		tree.addTreeSelectionListener(this);
		scrollTree=new JScrollPane(tree);
		split.add(scrollTree, JSplitPane.LEFT);
		calw.validate();
		split.setDividerLocation(0.2);
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		String a[]=new String [3];
		Booking checkbook= new Booking();
		String d = date.getText();
		if(d.length()==0){
			JOptionPane.showMessageDialog(null,"��ѯʱ�䲻��Ϊ�գ�","��ʾ",JOptionPane.WARNING_MESSAGE);
		}else{
			Pattern pattern = Pattern.compile("\\d+");
			Matcher matcher = pattern.matcher(d);
			int i=0;
			while (matcher.find()) {
				a[i]=matcher.group(0);
				i++;
			}
			checkbook.y=a[0];
			checkbook.m=a[1];
			checkbook.d=a[2];
			checkbook.booking();
		}
		
	}

}
