package restaurant_class;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;

public class Mybutton extends DefaultCellEditor{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4609324468114917964L;
	static String by,bm,bd;
	private JPanel panel;
	private JButton button;
	public Mybutton()
    {
		super(new JTextField());
		this.setClickCountToStart(1);
        this.initButton();
        this.initPanel();                                 // ���Ӱ�ť��
        this.panel.add(this.button);
    }
	private void initPanel()
    {
        this.panel = new JPanel();                       // panelʹ�þ��Զ�λ������button�Ͳ������������Ԫ��
        this.panel.setLayout(null);
    }
	private void initButton()
    {
        this.button = new JButton();                     // ���ð�ť�Ĵ�С��λ�á�
        this.button.setBounds(0, 0, 70, 15);
        this.button.addActionListener(new ActionListener()
        		{

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO �Զ����ɵķ������
						if(bm==null){
							JOptionPane.showMessageDialog(null,"��ѡ���·�","��ʾ",JOptionPane.WARNING_MESSAGE);
						}else if(bd==""){
							JOptionPane.showMessageDialog(null,"��Ч���ڣ�������ѡ�����ڣ�","��ʾ",JOptionPane.WARNING_MESSAGE);
						}else{
							Booking yuyue = new Booking();
							yuyue.m=bm;
							yuyue.y=by;
							yuyue.d=bd;
							yuyue.booking();
						}
						
					}
        	
        		});
    }
	public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) 
    { 
        // ֻΪ��ť��ֵ���ɡ�Ҳ����������������  
        this.button.setText(value == null ? "" : String.valueOf(value));
        bd=this.button.getText();
 
        return this.panel; 
    }
	public Object getCellEditorValue() 
    {
        return this.button.getText(); 
    }

}
