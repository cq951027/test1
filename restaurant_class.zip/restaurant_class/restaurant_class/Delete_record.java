package restaurant_class;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Delete_record extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String cover,d,t,tableid;
	String i="";
	JFrame delete;
	JTextField cname,date,times,tid;
	JLabel information;
	JButton sure,quit;
	Box basebox,boxV1,boxV2;
	void delete(){
		delete = new JFrame("ȡ��ԤԼ");
		delete.setLayout(new FlowLayout());
		boxV1=Box.createVerticalBox();
		boxV1.add(new JLabel("���������ڣ�"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV1.add(new JLabel("������ʱ��Σ�"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV1.add(new JLabel("��������Ҫȡ��ԤԼ�����ţ�"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV1.add(new JLabel("����������������"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV2=Box.createVerticalBox();
		date=new JTextField(d);
		boxV2.add(date);
		boxV2.add(Box.createVerticalStrut(8));
		times=new JTextField(t);
		boxV2.add(times);
		boxV2.add(Box.createVerticalStrut(8));
		tid=new JTextField(tableid);
		boxV2.add(tid);
		boxV2.add(Box.createVerticalStrut(8));
		cname=new JTextField(10);
		boxV2.add(cname);
		boxV2.add(Box.createVerticalStrut(8));
		basebox=Box.createHorizontalBox();
		basebox.add(boxV1);
		basebox.add(Box.createHorizontalStrut(16));
		basebox.add(boxV2);
		sure=new JButton("ȷ��");
		quit=new JButton("ȡ��");
		sure.addActionListener(this);
		quit.addActionListener(this);
		information = new JLabel();
		delete.add(basebox);
		delete.add(sure);
		delete.add(quit);
		delete.add(information);
		delete.setBounds(400, 300, 360, 360);
		delete.setVisible(true);
		delete.validate();
		delete.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		String flag=null,b1=null;
		if(e.getSource()==sure){
			Sql_delete sd=new Sql_delete();
			String name=cname.getText();
			String time=times.getText();
			String da=date.getText();
			String tnumber=tid.getText();
			String sql = "select custom_id from reservation where (date='"+da+"' and time='"+time+"' and table_id='"+tnumber+"')";
			Sql_connect sConnect= new Sql_connect();
			try {
				flag=sConnect.sqlconnect(sql,"custom_id");
			} catch (Exception e2) {
				// TODO �Զ����ɵ� catch ��
				e2.printStackTrace();
			}
			int f=Integer.parseInt(flag);
			String sql2="select name from customer where(customer_id='"+f+"')";
			try {
				b1=sConnect.sqlconnect(sql2,"name");
			} catch (Exception e3) {
				// TODO �Զ����ɵ� catch ��
				e3.printStackTrace();
			}
			if(flag.equals("0")){
				JOptionPane.showMessageDialog(null,"���������ԤԼ��Ϣ��","��ʾ",JOptionPane.WARNING_MESSAGE);
				cname.setText("");
				times.setText("");
				date.setText("");
				tid.setText("");
			}else if(!flag.equals("0")&&b1.equals(name)){
				try {
					sd.sqldrop("delete from reservation where (date='"+da+"' and time='"+time+"' and table_id='"+tnumber+"')");
					sd.sqldrop("delete from customer where(customer_id='"+f+"')");
					JOptionPane.showMessageDialog(null,"ȡ���ɹ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
					delete.dispose();
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		}
		if(e.getSource()==quit){
			delete.dispose();
		}
		
	}


}
