package restaurant_class;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class Sql_insertinformation {
	void sqlinserti(String a,String b,int c) throws Exception{
		Connection conn=null;
		PreparedStatement pst = null;
		String url ="jdbc:mysql://localhost:3306/bookingdb?"+
				"user=root&useUnicode=true&characterEncoding=UTF8";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("�ɹ�����mysql����");
			conn = DriverManager.getConnection(url);
			String sql = "insert into customer(name,phoneNumber,peopleNum) values(?,?,?) ";  
			pst = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, a);
			pst.setString(2, b);
			pst.setInt(3, c);
			pst.executeUpdate();
			pst.close();
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("�������ݴ���");
			e.printStackTrace();
		} finally {
			conn.close();
		}
	}

}
