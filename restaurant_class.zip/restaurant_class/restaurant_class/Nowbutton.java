package restaurant_class;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;

public class Nowbutton extends DefaultCellEditor{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static String flag,date,times,tid,t;
	private JPanel panel;
	private JButton button;
	Calendar cal=Calendar.getInstance();
	public Nowbutton ()
    {
		super(new JTextField());
		this.setClickCountToStart(1);
        this.initButton();
        this.initPanel();                                 // ���Ӱ�ť��
        this.panel.add(this.button);
    }
	private void initPanel()
    {
        this.panel = new JPanel();                       // panelʹ�þ��Զ�λ������button�Ͳ������������Ԫ��
        this.panel.setLayout(null);
    }
	private void initButton()
    {
        this.button = new JButton();                     // ���ð�ť�Ĵ�С��λ�á�
        this.button.setBounds(0, 0, 200, 20);
        this.button.addActionListener(new ActionListener()
        		{

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO �Զ����ɵķ������
						String fString=null;
						String d[]=new String[2];
						int s[]=new int[4];
						String f=flag.substring(flag.length()-3, flag.length());
						System.out.println(flag);
						Pattern pattern = Pattern.compile("\\d+");
						Matcher matcher = pattern.matcher(flag);
						Matcher matcher2 = pattern.matcher(times);
						int i=0;
						int j=0;
						while (matcher.find()) {
							d[i]=(matcher.group(0));
							i++;
						}
						while(matcher2.find()){
							s[j]=Integer.parseInt((matcher2.group(0)));
							j++;
						}
						int bew=(s[0]+s[2])/2;
						String time=String.valueOf(s[2])+":00-"+String.valueOf(s[2]+2)+":00";
						Sql_connect sc = new Sql_connect();
						String sql = "select custom_id from reservation where (date = '"+date+"' and time = '"+time+"' and table_id = "+d[0]+")";
						try {
							fString=sc.sqlconnect(sql,"custom_id");
						} catch (Exception e1) {
							// TODO �Զ����ɵ� catch ��
							e1.printStackTrace();
						}
						int m=cal.get(Calendar.HOUR_OF_DAY);
						if(f.equals("ûԤԼ")&&((m<=bew)||((m>bew)&&(fString.equals("0"))))){
							Now_add na = new Now_add();
							na.c=d[1];
							na.d=date;
							na.t=t;
							na.tableid=d[0];
						    na.nowadd("���ھͲ�");
						}else if(m>bew&&!fString.equals("0")){
							JOptionPane.showMessageDialog(null,"����ԤԼ�߽�Ҫ���ˣ�","��ʾ",JOptionPane.WARNING_MESSAGE);
						}else if(f.equals("��ԤԼ")){
							JOptionPane.showMessageDialog(null,"����������ԤԼ��","��ʾ",JOptionPane.WARNING_MESSAGE);
						}else if(f.equals("��ʹ��")){
							JOptionPane.showMessageDialog(null,"���������������ڳԣ�","��ʾ",JOptionPane.WARNING_MESSAGE);
						}
						}
						
        	
        		});
    }
	public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) 
    { 
        // ֻΪ��ť��ֵ���ɡ�Ҳ����������������  
        this.button.setText(value == null ? "" : String.valueOf(value));
        flag=this.button.getText();
 
        return this.panel; 
    }
	public Object getCellEditorValue() 
    {
        return this.button.getText(); 
    }

}
