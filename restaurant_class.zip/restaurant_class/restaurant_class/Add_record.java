package restaurant_class;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Add_record extends JFrame implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JFrame add;
	String co,d,t,tableid;
	JTextField cover,date,times,tid,cid,name,phone;
	JButton sure,quit;
	Box basebox,boxV1,boxV2;
	void add(String s){
		add = new JFrame(s);
		add.setLayout(new FlowLayout());
		boxV1=Box.createVerticalBox();
		boxV1.add(new JLabel("������������"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV1.add(new JLabel("���������ڣ�"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV1.add(new JLabel("������ʱ��Σ�"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV1.add(new JLabel("��������ҪԤԼ�����ţ�"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV1.add(new JLabel("����������������"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV1.add(new JLabel("���������ĵ绰��"));
		boxV1.add(Box.createVerticalStrut(8));
		boxV2=Box.createVerticalBox();
		cover=new JTextField(co);
		boxV2.add(cover);
		boxV2.add(Box.createVerticalStrut(8));
		date=new JTextField(d);
		boxV2.add(date);
		boxV2.add(Box.createVerticalStrut(8));
		times=new JTextField(t);
		boxV2.add(times);
		boxV2.add(Box.createVerticalStrut(8));
		tid=new JTextField(tableid);
		boxV2.add(tid);
		boxV2.add(Box.createVerticalStrut(8));
		name=new JTextField(10);
		boxV2.add(name);
		boxV2.add(Box.createVerticalStrut(8));
		phone=new JTextField(10);
		boxV2.add(phone);
		boxV2.add(Box.createVerticalStrut(8));
		basebox=Box.createHorizontalBox();
		basebox.add(boxV1);
		basebox.add(Box.createHorizontalStrut(16));
		basebox.add(boxV2);
		sure=new JButton("ȷ��");
		quit=new JButton("ȡ��");
		sure.addActionListener(this);
		quit.addActionListener(this);
		add.add(basebox);
		add.add(sure);
		add.add(quit);
		add.setBounds(400, 300, 300, 300);
		add.setVisible(true);
		add.validate();
		add.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		String flag=null,customid;
		int d[]=new int [3];
		int f[]=new int [4];
		Calendar now = Calendar.getInstance();
		if(e.getSource()==sure){
			Sql_insert si=new Sql_insert();
			Sql_insertinformation sii = new Sql_insertinformation();
			String c=cover.getText();
			String time=times.getText();
			String da=date.getText();
			String tnumber=tid.getText();
			String cname=name.getText();
			String cphone=phone.getText();
			Pattern pattern = Pattern.compile("\\d+");
			Matcher matcher = pattern.matcher(da);
			int i=0;
			int j=0;
			while (matcher.find()) {
				d[i]=Integer.parseInt(matcher.group(0));
				i++;
			}
			Matcher mat = pattern.matcher(time);
			while (mat.find()) {
				f[j]=Integer.parseInt(mat.group(0));
				j++;
			}
			System.out.println(f[0]);
			String sql="select custom_id from reservation where (date='"+da+"' and time='"+time+"' and table_id='"+tnumber+"')";
			Sql_connect sConnect= new Sql_connect();
			try {
				flag=sConnect.sqlconnect(sql,"custom_id");
			} catch (Exception e2) {
				// TODO �Զ����ɵ� catch ��
				e2.printStackTrace();
			}
			System.out.println(d[1]);
			if(flag.equals("0")&&cname.length()!=0&&time.length()!=0&&da.length()!=0&&tnumber.length()!=0&&cphone.length()!=0&&
					(d[0]>now.get(Calendar.YEAR)||(d[0]==now.get(Calendar.YEAR)&&(d[1]>(now.get(Calendar.MONTH)+1))
					||((d[0]==now.get(Calendar.YEAR))&&
					  (d[1]==(now.get(Calendar.MONTH)+1))&&
					  (d[2]>now.get(Calendar.DAY_OF_MONTH)) ) )||((d[0]==now.get(Calendar.YEAR))&&
							  (d[1]==(now.get(Calendar.MONTH)+1))&&
							  (d[2]==now.get(Calendar.DAY_OF_MONTH))&&(f[0]>now.get(Calendar.HOUR_OF_DAY)) ) ) ){
				try {
					sii.sqlinserti(cname, cphone, Integer.parseInt(c));
					String sql2="select customer_id from customer where (name='"+cname+"')";
					customid=sConnect.sqlconnect(sql2, "customer_id");
					si.sqlinsert(Integer.parseInt(c),da,time,Integer.parseInt(tnumber),Integer.parseInt(customid));
					JOptionPane.showMessageDialog(null,"ԤԼ�ɹ�","��ʾ",JOptionPane.INFORMATION_MESSAGE);
					add.dispose();
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				}else if(cname.length()==0||time.length()==0||da.length()==0||tnumber.length()==0||cphone.length()==0){
				JOptionPane.showMessageDialog(null,"ԤԼ��Ϣ�����пգ�","��ʾ",JOptionPane.WARNING_MESSAGE);
			}else if(!(d[0]>now.get(Calendar.YEAR)||(d[0]==now.get(Calendar.YEAR)&&(d[1]>(now.get(Calendar.MONTH)+1))
					||((d[0]==now.get(Calendar.YEAR))&&
							  (d[1]==(now.get(Calendar.MONTH)+1))&&
							  (d[2]>now.get(Calendar.DAY_OF_MONTH)) ) )||((d[0]==now.get(Calendar.YEAR))&&
									  (d[1]==(now.get(Calendar.MONTH)+1))&&
									  (d[2]==now.get(Calendar.DAY_OF_MONTH))&&(f[0]>now.get(Calendar.HOUR_OF_DAY)) ) )){
				JOptionPane.showMessageDialog(null,"ԤԼʱ�䲻��Ϊ��ȥʱ�䣡","��ʾ",JOptionPane.WARNING_MESSAGE);
				times.setText("");
				date.setText("");
			}else{
				JOptionPane.showMessageDialog(null,"������ԤԼ������ԤԼ��","��ʾ",JOptionPane.WARNING_MESSAGE);
				times.setText("");
				date.setText("");
				tid.setText("");
			}
		}
		if(e.getSource()==quit){
			add.dispose();
		}
		
	}

}
