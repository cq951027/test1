package restaurant_class;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


public class Sql_insert {
	void sqlinsert(int a,String b,String c,int d,int f) throws Exception{
		Connection conn=null;
		PreparedStatement pst = null;
		String url ="jdbc:mysql://localhost:3306/bookingdb?"+
				"user=root&useUnicode=true&characterEncoding=UTF8";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("�ɹ�����mysql����");
			conn = DriverManager.getConnection(url);
			String sql = "insert into reservation(covers,date,time,table_id,custom_id) values(?,?,?,?,?) ";  
			pst = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			pst.setInt(1, a);
			pst.setString(2, b);
			pst.setString(3, c);
			pst.setInt(4, d);
			pst.setInt(5, f);
			pst.executeUpdate();
			pst.close();
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("�������ݴ���");
			e.printStackTrace();
		} finally {
			conn.close();
		}
	}

}
