package restaurant_class;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Sql_connect {
	String a;
	String sqlconnect(String sql,String s)throws Exception{
		Connection conn=null;
		String url ="jdbc:mysql://localhost:3306/bookingdb?"+
				"user=root&useUnicode=true&characterEncoding=UTF8";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("�ɹ�����mysql����");
			conn = DriverManager.getConnection(url);
			Statement stmt= conn.createStatement();
			ResultSet rs =stmt.executeQuery(sql);
			if(rs.next()){
				a=rs.getString(s);
				
			}else {
				a="0";
			}
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("�������ݿ����");
			e.printStackTrace();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally{
			conn.close();
		}
		return a;
	}

}
