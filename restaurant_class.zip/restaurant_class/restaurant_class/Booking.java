package restaurant_class;

import java.awt.BorderLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;

public class Booking extends JFrame implements ItemListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String y,m,d;
	String dates,times;
	JFrame booking;
	JPanel panel;
	JComboBox<String> choicetimes;
	JTable table;
	JTextArea jta;
	String a[][] = new String[7][4];
	public void booking() {
		// TODO �Զ����ɵĹ��캯�����
		dates=y+"-"+m+"-"+d;
		times="8:00-10:00";
		booking=new JFrame("ԤԼ");
		booking.setLayout(new BorderLayout());
		choicetimes = new JComboBox<String>();
		Object location[] = {" ","1","2","3"};
		for(int i=0;i<7;i++){
			a[i][0] = "               "+String.valueOf(i+1);
		}
		String b=null,b1=null;
		String flag[] = new String [21];
		Sql_connect sc = new Sql_connect();
		for(int i=0;i<21;i++){
			String sql = "select custom_id from reservation where (date = '"+dates+"' and time = '8:00-10:00' and table_id = "+(i+1)+")";
			String sql1 = "select number_T from table_r where (table_id = "+(i+1)+")";
			try {
				b=sc.sqlconnect(sql,"custom_id");
				b1=sc.sqlconnect(sql1, "number_T");
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
			System.out.println(b);
			if(b.equals("0")){
				flag[i]="��"+(i+1)+"��("+b1+"����)ûԤԼ";
			}else {
				flag[i]="��"+(i+1)+"��("+b1+"����)��ԤԼ";
			}
		}
		System.out.println(dates+"��"+times);
		for(int i=0;i<3;i++){
			a[0][i+1]=flag[i];
			a[1][i+1]=flag[i+3];
			a[2][i+1]=flag[i+6];
			a[3][i+1]=flag[i+9];
			a[4][i+1]=flag[i+12];
			a[5][i+1]=flag[i+15];
			a[6][i+1]=flag[i+18];
		}
		table = new JTable(a,location);
		table.setBounds(getBounds());
		table.getColumnModel().getColumn(1).setCellEditor(new Mybookbutton());
		table.getColumnModel().getColumn(2).setCellEditor(new Mybookbutton());
		table.getColumnModel().getColumn(3).setCellEditor(new Mybookbutton());
		Mybookbutton.date=y+"-"+m+"-"+d;
		Mybookbutton.times=times;
		choicetimes.addItem("8:00-10:00");
		choicetimes.addItem("10:00-12:00");
		choicetimes.addItem("12:00-14:00");
		choicetimes.addItem("14:00-16:00");
		choicetimes.addItem("16:00-18:00");
		choicetimes.addItem("18:00-20:00");
		choicetimes.addItemListener(this);
		jta=new JTextArea();
		jta.setText("��ѡ������ڣ�"+dates);
		panel=new JPanel();
		panel.add(jta);
		panel.add(choicetimes);
		//booking.add(jta);
		//booking.add(choicetimes);
		booking.add(panel,BorderLayout.NORTH);
		booking.add(new JScrollPane(table),BorderLayout.CENTER);
		//add(new JScrollPane(area));
		booking.setBounds(400, 300, 600, 260);
		booking.setVisible(true);
		booking.validate();
		booking.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	public void itemStateChanged(ItemEvent e){
		// TODO �Զ����ɵķ������
		dates=y+"-"+m+"-"+d;
		times = choicetimes.getSelectedItem().toString();
		String b=null,b1=null;
		String flag[] = new String [21];
		Sql_connect sc = new Sql_connect();
		for(int i=0;i<21;i++){
			String sql = "select custom_id from reservation where (date = '"+dates+"' and time = '"+times+"'and table_id = "+(i+1)+")";
			String sql1 = "select number_T from table_r where (table_id = "+(i+1)+")";
			try {
				b=sc.sqlconnect(sql,"custom_id");
				b1=sc.sqlconnect(sql1, "number_T");
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
			if(b.equals("0")){
				flag[i]="��"+(i+1)+"��("+b1+"����)ûԤԼ";
			}else {
				flag[i]="��"+(i+1)+"��("+b1+"����)��ԤԼ";
			}
		}
		System.out.println(dates+"��"+times);
		for(int i=0;i<3;i++){
			a[0][i+1]=flag[i];
			a[1][i+1]=flag[i+3];
			a[2][i+1]=flag[i+6];
			a[3][i+1]=flag[i+9];
			a[4][i+1]=flag[i+12];
			a[5][i+1]=flag[i+15];
			a[6][i+1]=flag[i+18];
		}
		table.repaint();
		table.getColumnModel().getColumn(1).setCellEditor(new Mybookbutton());
		table.getColumnModel().getColumn(2).setCellEditor(new Mybookbutton());
		table.getColumnModel().getColumn(3).setCellEditor(new Mybookbutton());
		Mybookbutton.date=y+"-"+m+"-"+d;
		Mybookbutton.times=times;
	}

}
