package restaurant_class;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;

public class Mybookbutton extends DefaultCellEditor{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static String flag,date,times,tid;
	private JPanel panel;
	private JButton button;
	public Mybookbutton()
    {
		super(new JTextField());
		this.setClickCountToStart(1);
        this.initButton();
        this.initPanel();                                 // ���Ӱ�ť��
        this.panel.add(this.button);
    }
	private void initPanel()
    {
        this.panel = new JPanel();                       // panelʹ�þ��Զ�λ������button�Ͳ������������Ԫ��
        this.panel.setLayout(null);
    }
	private void initButton()
    {
        this.button = new JButton();                     // ���ð�ť�Ĵ�С��λ�á�
        this.button.setBounds(0, 0, 160, 20);
        this.button.addActionListener(new ActionListener()
        		{

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO �Զ����ɵķ������
						String d[]=new String[2];
						String f=flag.substring(flag.length()-3, flag.length());
						Pattern pattern = Pattern.compile("\\d+");
						Matcher matcher = pattern.matcher(flag);
						int i=0;
						while (matcher.find()) {
							d[i]=(matcher.group(0));
							i++;
						}
						if(f.equals("ûԤԼ")){
							Add_record arecord=new Add_record();
							arecord.co=d[1];
							arecord.d=date;
							arecord.t=times;
							arecord.tableid=d[0];
							arecord.add("ԤԼ");
						}else if(f.equals("��ԤԼ")){
							Delete_record drecord=new Delete_record();
							drecord.cover=d[1];
							drecord.d=date;
							drecord.t=times;
							drecord.tableid=d[0];
							drecord.delete();
						}
						}
						
        	
        		});
    }
	public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) 
    { 
        // ֻΪ��ť��ֵ���ɡ�Ҳ����������������  
        this.button.setText(value == null ? "" : String.valueOf(value));
        flag=this.button.getText();
 
        return this.panel; 
    }
	public Object getCellEditorValue() 
    {
        return this.button.getText(); 
    }


}
